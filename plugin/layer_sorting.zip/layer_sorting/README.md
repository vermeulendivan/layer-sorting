# layer-sorting
Sort all layers according to geometry in the QGIS layer list

## Installation




## How to use the plugin
